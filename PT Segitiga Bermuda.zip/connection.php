<?php
$hostname = "localhost";
$username = "root";
$password = "";
$dbName = "alusistadbs";

$connection = new mysqli($hostname, $username, $password, $dbName);
